# -Solución-Proyecto-C116

La carpeta sólo tiene la carpeta static, la carpeta templates y el archivo app.py. Tienes que crear un entorno virtual e instalar la librería flask dentro.